'use client';

import { ShoppingBag } from 'lucide-react';
import { useCart } from './CartContext';

export default function Header() {
  const { itemCount, setIsCartOpen } = useCart();

  return (
    <header className="sticky top-0 z-40 bg-cream/90 backdrop-blur border-b border-pink/30">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-4 sm:px-6 py-4">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🪔</span>
          <div>
            <h1 className="font-display font-semibold text-lg sm:text-2xl text-chocolate tracking-tight leading-tight">
              Krishna Mistha Bhandar
            </h1>
            <p className="text-[11px] text-chocolate/50 -mt-0.5 hidden sm:block">
              Sweets · Cakes · Party Bundles
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsCartOpen(true)}
          className="relative flex items-center gap-2 bg-white border border-pink/50 rounded-full pl-4 pr-3 py-2 shadow-soft hover:shadow-softHover transition-all duration-200 hover:-translate-y-0.5"
          aria-label="Open cart"
        >
          <span className="hidden sm:inline text-chocolate font-medium text-sm">Cart</span>
          <ShoppingBag size={20} className="text-strawberry" />
          {itemCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-strawberry text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
              {itemCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
}
