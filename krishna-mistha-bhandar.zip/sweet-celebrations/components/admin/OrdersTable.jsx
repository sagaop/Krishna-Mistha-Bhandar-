'use client';

import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

export default function OrdersTable() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  async function fetchOrders() {
    setLoading(true);

    // ---- ACTUAL SUPABASE FETCH CALL ----
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false });
    // --------------------------------------

    if (error) {
      console.error('Error fetching orders:', error);
    } else {
      setOrders(data || []);
    }
    setLoading(false);
  }

  useEffect(() => {
    fetchOrders();

    // Live-update the table when new orders come in from the storefront
    const channel = supabase
      .channel('orders-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'orders' },
        () => fetchOrders()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  async function toggleStatus(order) {
    const newStatus = order.status === 'Pending' ? 'Delivered' : 'Pending';

    // ---- ACTUAL SUPABASE UPDATE CALL ----
    const { error } = await supabase
      .from('orders')
      .update({ status: newStatus })
      .eq('id', order.id);
    // ---------------------------------------

    if (error) {
      console.error('Error updating status:', error);
      return;
    }

    setOrders((prev) =>
      prev.map((o) => (o.id === order.id ? { ...o, status: newStatus } : o))
    );
  }

  return (
    <div className="bg-white rounded-3xl shadow-soft border border-pink/30 overflow-hidden">
      <div className="flex items-center justify-between px-6 py-4 border-b border-pink/20">
        <h3 className="font-display font-semibold text-lg text-chocolate">
          Incoming Orders
        </h3>
        <button
          onClick={fetchOrders}
          className="text-sm text-strawberry font-medium hover:underline"
        >
          Refresh
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-cream text-chocolate/70 uppercase text-xs">
            <tr>
              <th className="text-left px-6 py-3 font-semibold">Customer</th>
              <th className="text-left px-6 py-3 font-semibold">Phone</th>
              <th className="text-left px-6 py-3 font-semibold">Address</th>
              <th className="text-left px-6 py-3 font-semibold">Items</th>
              <th className="text-left px-6 py-3 font-semibold">Total</th>
              <th className="text-left px-6 py-3 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-chocolate/50">
                  Loading orders…
                </td>
              </tr>
            ) : orders.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-chocolate/50">
                  No orders yet.
                </td>
              </tr>
            ) : (
              orders.map((order) => (
                <tr key={order.id} className="border-t border-pink/10 align-top">
                  <td className="px-6 py-4 font-medium text-chocolate whitespace-nowrap">
                    {order.customer_name}
                  </td>
                  <td className="px-6 py-4 text-chocolate/80 whitespace-nowrap">
                    {order.phone_number}
                  </td>
                  <td className="px-6 py-4 text-chocolate/80 max-w-[220px]">
                    {order.delivery_address}
                  </td>
                  <td className="px-6 py-4 text-chocolate/80">
                    <ul className="space-y-0.5">
                      {(order.items || []).map((it, idx) => (
                        <li key={idx}>
                          {it.quantity}× {it.title}
                        </li>
                      ))}
                    </ul>
                  </td>
                  <td className="px-6 py-4 text-strawberry font-semibold whitespace-nowrap">
                    Rs. {Number(order.total_price).toFixed(2)}
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => toggleStatus(order)}
                      className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide transition-all ${
                        order.status === 'Delivered'
                          ? 'bg-green-100 text-green-700 hover:bg-green-200'
                          : 'bg-gold/20 text-gold hover:bg-gold/30'
                      }`}
                    >
                      {order.status}
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
