'use client';

import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { CartProvider } from '../components/CartContext';
import Header from '../components/Header';
import Hero from '../components/Hero';
import ProductCard from '../components/ProductCard';
import CartModal from '../components/CartModal';

export default function StorefrontPage() {
  const [bundles, setBundles] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    async function loadShop() {
      setLoading(true);

      // ---- FETCH BUNDLES ----
      const { data: bundleData, error: bundleError } = await supabase
        .from('bundles')
        .select('*')
        .order('created_at', { ascending: false });

      // ---- FETCH PRODUCTS ----
      const { data: productData, error: productError } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (bundleError) console.error('Error loading bundles:', bundleError);
      if (productError) console.error('Error loading products:', productError);

      setBundles((bundleData || []).map((b) => ({ ...b, type: 'bundle' })));
      setProducts((productData || []).map((p) => ({ ...p, type: 'product' })));
      setLoading(false);
    }

    loadShop();
  }, []);

  const categories = ['All', 'Sweets', 'Cake', 'Drink', 'Decor'];
  const filteredProducts =
    activeCategory === 'All'
      ? products
      : products.filter((p) => p.category === activeCategory);

  return (
    <CartProvider>
      <div className="min-h-screen bg-cream font-body">
        <Header />
        <Hero />

        {/* PARTY BUNDLES */}
        <section id="bundles" className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
          <div className="flex items-center gap-3 mb-6">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-chocolate">
              Party Bundles
            </h2>
            <span className="bg-gold/20 text-gold text-xs font-bold uppercase px-3 py-1 rounded-full">
              Best Value
            </span>
          </div>

          {loading ? (
            <p className="text-chocolate/60">Loading bundles…</p>
          ) : bundles.length === 0 ? (
            <p className="text-chocolate/60">No bundles yet — check back soon!</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {bundles.map((bundle) => (
                <ProductCard key={bundle.id} item={bundle} />
              ))}
            </div>
          )}
        </section>

        {/* INDIVIDUAL PRODUCTS */}
        <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-chocolate mb-6">
            Shop by Category
          </h2>

          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2 rounded-full text-sm font-medium border transition-all ${
                  activeCategory === cat
                    ? 'bg-strawberry text-white border-strawberry'
                    : 'bg-white text-chocolate border-pink/40 hover:bg-pink/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {loading ? (
            <p className="text-chocolate/60">Loading products…</p>
          ) : filteredProducts.length === 0 ? (
            <p className="text-chocolate/60">No products in this category yet.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} item={product} />
              ))}
            </div>
          )}
        </section>

        <footer className="text-center text-chocolate/50 text-sm py-8 border-t border-pink/30">
          🪔 Krishna Mistha Bhandar — made with love.
        </footer>

        <CartModal />
      </div>
    </CartProvider>
  );
}
