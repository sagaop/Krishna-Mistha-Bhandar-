'use client';

import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

// Lets the shop owner add/remove tags (Best Seller, Low Price Today, etc.)
// on anything already saved, and delete items — all fully owner-controlled.
export default function ManageCatalog() {
  const [items, setItems] = useState([]); // merged products + bundles
  const [loading, setLoading] = useState(true);
  const [tagInputs, setTagInputs] = useState({}); // { [itemId]: 'typed text' }

  async function fetchItems() {
    setLoading(true);

    const { data: products, error: pErr } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    const { data: bundles, error: bErr } = await supabase
      .from('bundles')
      .select('*')
      .order('created_at', { ascending: false });

    if (pErr) console.error(pErr);
    if (bErr) console.error(bErr);

    const merged = [
      ...(products || []).map((p) => ({ ...p, _table: 'products' })),
      ...(bundles || []).map((b) => ({ ...b, _table: 'bundles' })),
    ];

    setItems(merged);
    setLoading(false);
  }

  useEffect(() => {
    fetchItems();
  }, []);

  async function addTag(item) {
    const value = (tagInputs[item.id] || '').trim();
    if (!value) return;
    const currentTags = Array.isArray(item.tags) ? item.tags : [];
    if (currentTags.includes(value)) {
      setTagInputs((prev) => ({ ...prev, [item.id]: '' }));
      return;
    }
    const newTags = [...currentTags, value];

    const { error } = await supabase
      .from(item._table)
      .update({ tags: newTags })
      .eq('id', item.id);

    if (error) {
      console.error(error);
      return;
    }

    setItems((prev) =>
      prev.map((i) => (i.id === item.id ? { ...i, tags: newTags } : i))
    );
    setTagInputs((prev) => ({ ...prev, [item.id]: '' }));
  }

  async function removeTag(item, tag) {
    const newTags = (item.tags || []).filter((t) => t !== tag);

    const { error } = await supabase
      .from(item._table)
      .update({ tags: newTags })
      .eq('id', item.id);

    if (error) {
      console.error(error);
      return;
    }

    setItems((prev) =>
      prev.map((i) => (i.id === item.id ? { ...i, tags: newTags } : i))
    );
  }

  async function deleteItem(item) {
    const confirmed = window.confirm(`Delete "${item.title}"? This cannot be undone.`);
    if (!confirmed) return;

    const { error } = await supabase.from(item._table).delete().eq('id', item.id);

    if (error) {
      console.error(error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
  }

  return (
    <div className="bg-white rounded-3xl shadow-soft border border-pink/30 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold text-lg text-chocolate">
          Manage Products & Tags
        </h3>
        <button onClick={fetchItems} className="text-sm text-strawberry font-medium hover:underline">
          Refresh
        </button>
      </div>

      {loading ? (
        <p className="text-chocolate/60 text-sm">Loading…</p>
      ) : items.length === 0 ? (
        <p className="text-chocolate/60 text-sm">Nothing saved yet — add a product above.</p>
      ) : (
        <div className="space-y-4">
          {items.map((item) => (
            <div
              key={item.id}
              className="border border-pink/20 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center gap-4"
            >
              <img
                src={item.image_url || 'https://placehold.co/100x100/FFF8F0/3B2525?text=%F0%9F%8D%B0'}
                alt={item.title}
                className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
              />

              <div className="flex-1 min-w-0">
                <p className="font-semibold text-chocolate truncate">{item.title}</p>
                <p className="text-strawberry text-sm font-medium">
                  Rs. {Number(item.price).toFixed(2)} · {item._table === 'bundles' ? 'Bundle' : item.category}
                </p>

                <div className="flex flex-wrap gap-1.5 mt-2">
                  {(item.tags || []).map((tag) => (
                    <span
                      key={tag}
                      className="flex items-center gap-1 bg-gold/15 text-xs font-semibold px-2.5 py-1 rounded-full"
                      style={{ color: '#a87a1f' }}
                    >
                      {tag}
                      <button
                        onClick={() => removeTag(item, tag)}
                        className="hover:text-strawberry font-bold"
                        aria-label={`Remove ${tag}`}
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>

                <div className="flex gap-2 mt-2">
                  <input
                    value={tagInputs[item.id] || ''}
                    onChange={(e) =>
                      setTagInputs((prev) => ({ ...prev, [item.id]: e.target.value }))
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addTag(item);
                      }
                    }}
                    placeholder='e.g. "Best Seller"'
                    className="text-sm flex-1 rounded-lg border border-pink/40 px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-strawberry/40"
                  />
                  <button
                    onClick={() => addTag(item)}
                    className="text-sm bg-gold/90 hover:bg-gold text-white font-semibold px-3 rounded-lg"
                  >
                    Add Tag
                  </button>
                </div>
              </div>

              <button
                onClick={() => deleteItem(item)}
                className="self-start sm:self-center text-sm text-strawberry/70 hover:text-strawberry font-medium border border-strawberry/30 hover:bg-strawberry/10 rounded-full px-4 py-1.5"
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
