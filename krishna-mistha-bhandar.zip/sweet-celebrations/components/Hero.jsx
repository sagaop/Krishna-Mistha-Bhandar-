'use client';

export default function Hero() {
  function scrollToBundles() {
    document.getElementById('bundles')?.scrollIntoView({ behavior: 'smooth' });
  }

  return (
    <section className="bg-gradient-to-b from-pink/20 to-cream px-4 sm:px-6 py-16 sm:py-24">
      <div className="max-w-4xl mx-auto text-center">
        <span className="inline-block bg-white text-strawberry text-xs font-semibold tracking-wide uppercase px-4 py-1.5 rounded-full shadow-soft mb-5">
          Sweets • Cakes • Drinks • Decor • Bundles
        </span>
        <h2 className="font-display text-4xl sm:text-6xl font-bold text-chocolate leading-tight mb-4">
          Every Celebration, <br className="hidden sm:block" />
          <span className="text-strawberry">Made Sweeter.</span>
        </h2>
        <p className="text-chocolate/70 text-base sm:text-lg max-w-xl mx-auto mb-8">
          Fresh mishti, cakes, party drinks, and gorgeous decor — bundled
          together so throwing the perfect celebration takes zero stress.
        </p>
        <button
          onClick={scrollToBundles}
          className="bg-strawberry hover:bg-strawberry/90 text-white font-semibold px-8 py-3.5 rounded-full shadow-softHover transition-all duration-200 hover:-translate-y-0.5"
        >
          Shop Party Bundles 🎉
        </button>
      </div>
    </section>
  );
}
