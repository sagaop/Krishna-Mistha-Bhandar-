-- ============================================================
-- KRISHNA MISTHA BHANDAR — SUPABASE SCHEMA
-- Copy/paste this entire file into: Supabase Dashboard > SQL Editor > New Query > Run
-- ============================================================

-- Clean slate (safe to re-run while building)
drop table if exists public.orders cascade;
drop table if exists public.bundles cascade;
drop table if exists public.products cascade;

-- ------------------------------------------------------------
-- PRODUCTS (single items: sweets, cakes, drinks, decor)
-- `tags` is a free-form list you control from the Admin panel —
-- e.g. {"Best Seller"}, {"Low Price Today"}, {"New"}, or empty.
-- Nothing is pre-set here; you decide what tags exist and which
-- products carry them, entirely from the Admin panel.
-- ------------------------------------------------------------
create table public.products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text default '',
  category text not null check (category in ('Sweets', 'Cake', 'Drink', 'Decor')),
  price numeric(10,2) not null check (price >= 0),
  image_url text default '',
  tags text[] not null default '{}',
  created_at timestamptz default now()
);

-- ------------------------------------------------------------
-- BUNDLES (party packages: e.g. 1 Cake + 10 Candles + 2L Drink)
-- included_items is a simple JSON array of strings describing what's inside.
-- Same free-form `tags` column as products.
-- ------------------------------------------------------------
create table public.bundles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text default '',
  included_items jsonb not null default '[]'::jsonb,
  price numeric(10,2) not null check (price >= 0),
  image_url text default '',
  tags text[] not null default '{}',
  created_at timestamptz default now()
);

-- ------------------------------------------------------------
-- ORDERS (checkout submissions from the storefront)
-- Prices are stored in NPR (Nepali Rupees).
-- items is a JSON snapshot of the cart at checkout time:
-- [{ "id": "...", "title": "...", "price": 250.00, "quantity": 2, "type": "product" }]
-- ------------------------------------------------------------
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone_number text not null,
  delivery_address text not null,
  items jsonb not null default '[]'::jsonb,
  total_price numeric(10,2) not null check (total_price >= 0),
  status text not null default 'Pending' check (status in ('Pending', 'Delivered')),
  created_at timestamptz default now()
);

-- ------------------------------------------------------------
-- ROW LEVEL SECURITY
-- The storefront (public key) needs to READ products/bundles and
-- INSERT orders. The Admin dashboard uses the same public key in
-- this simple/free setup, so it can also manage products, bundles,
-- and update order status. See README-SETUP.md for how to lock
-- /admin down with a login later.
-- ------------------------------------------------------------

alter table public.products enable row level security;
alter table public.bundles enable row level security;
alter table public.orders enable row level security;

create policy "Public can view products" on public.products for select using (true);
create policy "Public can view bundles" on public.bundles for select using (true);

create policy "Anyone can insert products" on public.products for insert with check (true);
create policy "Anyone can update products" on public.products for update using (true);
create policy "Anyone can delete products" on public.products for delete using (true);

create policy "Anyone can insert bundles" on public.bundles for insert with check (true);
create policy "Anyone can update bundles" on public.bundles for update using (true);
create policy "Anyone can delete bundles" on public.bundles for delete using (true);

create policy "Anyone can create an order" on public.orders for insert with check (true);
create policy "Anyone can view orders" on public.orders for select using (true);
create policy "Anyone can update order status" on public.orders for update using (true);

-- ------------------------------------------------------------
-- No seed data on purpose: your shop starts completely empty.
-- Add your own products, bundles, photos, prices and tags from
-- the /admin page once your site is live.
-- ------------------------------------------------------------
