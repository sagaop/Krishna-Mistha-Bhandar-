'use client';

import ProductForm from '../../components/admin/ProductForm';
import ManageCatalog from '../../components/admin/ManageCatalog';
import OrdersTable from '../../components/admin/OrdersTable';

export default function AdminPage() {
  return (
    <div className="min-h-screen bg-cream font-body">
      <header className="bg-white border-b border-pink/30 px-6 py-5">
        <div className="max-w-6xl mx-auto flex items-center gap-2">
          <span className="text-2xl">🪔</span>
          <h1 className="font-display font-semibold text-xl text-chocolate">
            Krishna Mistha Bhandar — Admin Dashboard
          </h1>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <ProductForm />
          </div>
          <div className="lg:col-span-2">
            <OrdersTable />
          </div>
        </div>

        <ManageCatalog />
      </main>
    </div>
  );
}
