'use client';

import { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

const CATEGORIES = ['Sweets', 'Cake', 'Drink', 'Decor', 'Bundle'];

export default function ProductForm({ onSaved }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    category: 'Sweets',
    includedItems: '', // comma-separated, only used when category === 'Bundle'
    price: '',
    imageUrl: '',
  });
  const [tags, setTags] = useState([]); // fully owner-controlled, e.g. "Best Seller", "Low Price Today"
  const [tagInput, setTagInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null); // { type: 'success' | 'error', text }

  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  function addTag() {
    const value = tagInput.trim();
    if (!value) return;
    if (tags.includes(value)) {
      setTagInput('');
      return;
    }
    setTags((prev) => [...prev, value]);
    setTagInput('');
  }

  function removeTag(tag) {
    setTags((prev) => prev.filter((t) => t !== tag));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setMessage(null);

    if (!form.title.trim() || !form.price) {
      setMessage({ type: 'error', text: 'Title and price are required.' });
      return;
    }

    setSaving(true);

    const isBundle = form.category === 'Bundle';

    // ---- ACTUAL SUPABASE INSERT CALL ----
    const { error } = isBundle
      ? await supabase.from('bundles').insert([
          {
            title: form.title.trim(),
            description: form.description.trim(),
            included_items: form.includedItems
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean),
            price: parseFloat(form.price),
            image_url: form.imageUrl.trim(),
            tags,
          },
        ])
      : await supabase.from('products').insert([
          {
            title: form.title.trim(),
            description: form.description.trim(),
            category: form.category,
            price: parseFloat(form.price),
            image_url: form.imageUrl.trim(),
            tags,
          },
        ]);
    // ---------------------------------------

    setSaving(false);

    if (error) {
      console.error(error);
      setMessage({ type: 'error', text: 'Failed to save. Check console for details.' });
      return;
    }

    setMessage({ type: 'success', text: `${isBundle ? 'Bundle' : 'Product'} saved!` });
    setForm({
      title: '',
      description: '',
      category: 'Sweets',
      includedItems: '',
      price: '',
      imageUrl: '',
    });
    setTags([]);
    setTagInput('');
    onSaved?.();
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-3xl shadow-soft border border-pink/30 p-6 space-y-4"
    >
      <h3 className="font-display font-semibold text-lg text-chocolate mb-2">
        Create Product / Bundle
      </h3>

      <div>
        <label className="block text-sm font-medium text-chocolate mb-1">Title</label>
        <input
          value={form.title}
          onChange={(e) => update('title', e.target.value)}
          className="w-full rounded-xl border border-pink/40 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-strawberry/50"
          placeholder="e.g. Kaju Katli Box (500g)"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-chocolate mb-1">Description</label>
        <textarea
          value={form.description}
          onChange={(e) => update('description', e.target.value)}
          rows={2}
          className="w-full rounded-xl border border-pink/40 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-strawberry/50"
          placeholder="Short description shown on the storefront card"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-chocolate mb-1">Category</label>
          <select
            value={form.category}
            onChange={(e) => update('category', e.target.value)}
            className="w-full rounded-xl border border-pink/40 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-strawberry/50 bg-white"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-chocolate mb-1">Price (Rs.)</label>
          <input
            type="number"
            step="0.01"
            min="0"
            value={form.price}
            onChange={(e) => update('price', e.target.value)}
            className="w-full rounded-xl border border-pink/40 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-strawberry/50"
            placeholder="450.00"
          />
        </div>
      </div>

      {form.category === 'Bundle' && (
        <div>
          <label className="block text-sm font-medium text-chocolate mb-1">
            Included Items (comma-separated)
          </label>
          <input
            value={form.includedItems}
            onChange={(e) => update('includedItems', e.target.value)}
            className="w-full rounded-xl border border-pink/40 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-strawberry/50"
            placeholder="1x Mishti Box, 1x Cake, 10x Candles"
          />
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-chocolate mb-1">Image URL</label>
        <input
          value={form.imageUrl}
          onChange={(e) => update('imageUrl', e.target.value)}
          className="w-full rounded-xl border border-pink/40 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-strawberry/50"
          placeholder="https://..."
        />
      </div>

      {/* ---- Fully owner-controlled tags: type anything, add it, remove it later ---- */}
      <div>
        <label className="block text-sm font-medium text-chocolate mb-1">
          Tags (optional — e.g. "Best Seller", "Low Price Today")
        </label>
        <div className="flex gap-2">
          <input
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addTag();
              }
            }}
            className="flex-1 rounded-xl border border-pink/40 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-strawberry/50"
            placeholder="Type a tag and press Add"
          />
          <button
            type="button"
            onClick={addTag}
            className="bg-gold/90 hover:bg-gold text-white font-semibold px-4 rounded-xl transition-colors"
          >
            Add
          </button>
        </div>
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-3">
            {tags.map((tag) => (
              <span
                key={tag}
                className="flex items-center gap-1.5 bg-gold/15 text-gold-800 text-xs font-semibold px-3 py-1.5 rounded-full"
                style={{ color: '#a87a1f' }}
              >
                {tag}
                <button
                  type="button"
                  onClick={() => removeTag(tag)}
                  className="hover:text-strawberry font-bold"
                  aria-label={`Remove tag ${tag}`}
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        )}
      </div>

      {message && (
        <p
          className={`text-sm font-medium ${
            message.type === 'success' ? 'text-green-600' : 'text-strawberry'
          }`}
        >
          {message.text}
        </p>
      )}

      <button
        type="submit"
        disabled={saving}
        className="w-full bg-strawberry disabled:opacity-60 hover:bg-strawberry/90 text-white font-semibold py-3 rounded-full shadow-soft transition-all"
      >
        {saving ? 'Saving…' : 'Save to Database'}
      </button>
    </form>
  );
}
