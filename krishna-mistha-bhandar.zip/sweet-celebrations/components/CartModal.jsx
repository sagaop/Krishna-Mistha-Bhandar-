'use client';

import { useState } from 'react';
import { X, Minus, Plus, Trash2 } from 'lucide-react';
import { useCart } from './CartContext';
import { supabase } from '../lib/supabaseClient';

export default function CartModal() {
  const {
    items,
    total,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateQuantity,
    clearCart,
  } = useCart();

  const [step, setStep] = useState('cart'); // 'cart' | 'checkout' | 'success'
  const [form, setForm] = useState({ name: '', phone: '', address: '' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isCartOpen) return null;

  function handleClose() {
    setIsCartOpen(false);
    // reset to cart view after the panel closes so it's fresh next time
    setTimeout(() => setStep('cart'), 300);
  }

  async function handlePlaceOrder(e) {
    e.preventDefault();
    setError('');

    if (!form.name.trim() || !form.phone.trim() || !form.address.trim()) {
      setError('Please fill in your name, phone number, and delivery address.');
      return;
    }
    if (items.length === 0) {
      setError('Your cart is empty.');
      return;
    }

    setSubmitting(true);

    // ---- THIS IS THE ACTUAL SUPABASE INSERT CALL FOR CHECKOUT ----
    const { error: insertError } = await supabase.from('orders').insert([
      {
        customer_name: form.name.trim(),
        phone_number: form.phone.trim(),
        delivery_address: form.address.trim(),
        items: items.map((i) => ({
          id: i.id,
          title: i.title,
          price: i.price,
          quantity: i.quantity,
          type: i.type,
        })),
        total_price: total,
        status: 'Pending',
      },
    ]);
    // ----------------------------------------------------------------

    setSubmitting(false);

    if (insertError) {
      console.error(insertError);
      setError('Something went wrong placing your order. Please try again.');
      return;
    }

    clearCart();
    setStep('success');
  }

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* backdrop */}
      <div
        className="absolute inset-0 bg-chocolate/40 backdrop-blur-sm"
        onClick={handleClose}
      />

      {/* panel */}
      <div className="relative w-full sm:w-[420px] h-full bg-cream shadow-2xl flex flex-col animate-[slideIn_0.25s_ease-out]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-pink/30">
          <h2 className="font-display font-semibold text-lg text-chocolate">
            {step === 'cart' && 'Your Cart'}
            {step === 'checkout' && 'Delivery Details'}
            {step === 'success' && 'Order Placed!'}
          </h2>
          <button
            onClick={handleClose}
            className="p-2 rounded-full hover:bg-pink/20 transition-colors"
            aria-label="Close cart"
          >
            <X size={20} className="text-chocolate" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {step === 'cart' && (
            <>
              {items.length === 0 ? (
                <p className="text-chocolate/60 text-center mt-12">
                  Your cart is empty. Go add something sweet! 🍰
                </p>
              ) : (
                <ul className="space-y-4">
                  {items.map((item) => (
                    <li
                      key={item.id}
                      className="bg-white rounded-2xl p-4 shadow-soft flex items-center justify-between gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-chocolate truncate">{item.title}</p>
                        <p className="text-strawberry font-semibold text-sm">
                          Rs. {item.price.toFixed(2)}
                        </p>
                        <div className="flex items-center gap-2 mt-2">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-7 h-7 flex items-center justify-center rounded-full bg-cream border border-pink/40 text-chocolate hover:bg-pink/20"
                          >
                            <Minus size={14} />
                          </button>
                          <span className="text-sm w-5 text-center text-chocolate">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-7 h-7 flex items-center justify-center rounded-full bg-cream border border-pink/40 text-chocolate hover:bg-pink/20"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="p-2 rounded-full hover:bg-strawberry/10 text-strawberry/70 hover:text-strawberry"
                        aria-label="Remove item"
                      >
                        <Trash2 size={16} />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}

          {step === 'checkout' && (
            <form onSubmit={handlePlaceOrder} className="space-y-4" id="checkout-form">
              <div>
                <label className="block text-sm font-medium text-chocolate mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full rounded-xl border border-pink/40 px-4 py-2.5 bg-white text-chocolate focus:outline-none focus:ring-2 focus:ring-strawberry/50"
                  placeholder="Jane Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-chocolate mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full rounded-xl border border-pink/40 px-4 py-2.5 bg-white text-chocolate focus:outline-none focus:ring-2 focus:ring-strawberry/50"
                  placeholder="98XXXXXXXX"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-chocolate mb-1">
                  Delivery Address
                </label>
                <textarea
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  rows={3}
                  className="w-full rounded-xl border border-pink/40 px-4 py-2.5 bg-white text-chocolate focus:outline-none focus:ring-2 focus:ring-strawberry/50"
                  placeholder="123 Main St, Apt 4B, City"
                />
              </div>
              {error && <p className="text-strawberry text-sm">{error}</p>}
            </form>
          )}

          {step === 'success' && (
            <div className="text-center mt-12 space-y-3">
              <p className="text-5xl">🎉</p>
              <p className="font-display font-semibold text-chocolate text-lg">
                Thank you, {form.name.split(' ')[0] || 'friend'}!
              </p>
              <p className="text-chocolate/70 text-sm">
                Your order has been received and is now pending confirmation.
                We'll be in touch at {form.phone}.
              </p>
            </div>
          )}
        </div>

        {/* footer actions */}
        <div className="border-t border-pink/30 px-5 py-4 space-y-3 bg-cream">
          {(step === 'cart' || step === 'checkout') && (
            <div className="flex items-center justify-between">
              <span className="text-chocolate font-medium">Total</span>
              <span className="text-strawberry font-bold text-xl">
                Rs. {total.toFixed(2)}
              </span>
            </div>
          )}

          {step === 'cart' && (
            <button
              disabled={items.length === 0}
              onClick={() => setStep('checkout')}
              className="w-full bg-strawberry disabled:opacity-40 hover:bg-strawberry/90 text-white font-semibold py-3 rounded-full shadow-soft transition-all"
            >
              Proceed to Checkout
            </button>
          )}

          {step === 'checkout' && (
            <div className="flex gap-3">
              <button
                onClick={() => setStep('cart')}
                className="flex-1 border border-pink/50 text-chocolate font-medium py-3 rounded-full hover:bg-pink/10 transition-all"
              >
                Back
              </button>
              <button
                type="submit"
                form="checkout-form"
                disabled={submitting}
                className="flex-1 bg-strawberry disabled:opacity-60 hover:bg-strawberry/90 text-white font-semibold py-3 rounded-full shadow-soft transition-all"
              >
                {submitting ? 'Placing Order…' : 'Place Order'}
              </button>
            </div>
          )}

          {step === 'success' && (
            <button
              onClick={handleClose}
              className="w-full bg-chocolate hover:bg-chocolate/90 text-white font-semibold py-3 rounded-full transition-all"
            >
              Continue Shopping
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
