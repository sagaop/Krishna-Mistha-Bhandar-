import './globals.css';

export const metadata = {
  title: 'Krishna Mistha Bhandar | Sweets, Cakes & Party Supplies',
  description: 'Fresh mishti, cakes, drinks, decor, and party bundles delivered fresh.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Inter:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
