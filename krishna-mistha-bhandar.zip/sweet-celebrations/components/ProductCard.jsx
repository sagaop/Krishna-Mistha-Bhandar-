'use client';

import { useCart } from './CartContext';

// item shape:
// { id, title, description, price, image_url, tags: string[], type: 'product' | 'bundle', included_items?: string[] }
// `tags` is entirely owner-controlled from the Admin panel — nothing is
// pre-assigned. A product only shows "Best Seller", "Low Price Today", etc.
// if you added that tag to it yourself.
export default function ProductCard({ item }) {
  const { addToCart } = useCart();
  const isBundle = item.type === 'bundle';
  const tags = Array.isArray(item.tags) ? item.tags : [];

  return (
    <div className="bg-white rounded-3xl border border-pink/30 shadow-soft hover:shadow-softHover transition-all duration-300 hover:-translate-y-1 overflow-hidden flex flex-col">
      <div className="relative">
        <img
          src={item.image_url || 'https://placehold.co/500x400/FFF8F0/3B2525?text=Krishna+Mistha+Bhandar'}
          alt={item.title}
          className="w-full h-44 sm:h-48 object-cover"
        />
        {/* Structural label — this just says what kind of listing it is,
            it's not an opinion/tag */}
        {isBundle && (
          <span className="absolute top-3 right-3 bg-pink text-chocolate text-xs font-bold uppercase tracking-wide px-3 py-1 rounded-full shadow-soft">
            Bundle
          </span>
        )}

        {/* Owner-controlled tags, e.g. "Best Seller", "Low Price Today" */}
        {tags.length > 0 && (
          <div className="absolute top-3 left-3 flex flex-col gap-1.5 items-start">
            {tags.map((tag, idx) => (
              <span
                key={idx}
                className="bg-gold text-white text-xs font-bold uppercase tracking-wide px-3 py-1 rounded-full shadow-soft"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="p-5 flex flex-col flex-1">
        <h3 className="font-display font-semibold text-lg text-chocolate mb-1">
          {item.title}
        </h3>

        {item.description && (
          <p className="text-chocolate/60 text-sm mb-3">{item.description}</p>
        )}

        {isBundle && Array.isArray(item.included_items) && item.included_items.length > 0 && (
          <ul className="mb-4 space-y-1">
            {item.included_items.map((inc, idx) => (
              <li key={idx} className="text-sm text-chocolate/80 flex items-start gap-1.5">
                <span className="text-gold mt-0.5">✓</span>
                <span>{inc}</span>
              </li>
            ))}
          </ul>
        )}

        <div className="mt-auto flex items-center justify-between pt-3">
          <span className="text-strawberry font-bold text-xl">
            Rs. {Number(item.price).toFixed(2)}
          </span>
          <button
            onClick={() =>
              addToCart({
                id: item.id,
                title: item.title,
                price: Number(item.price),
                type: item.type,
              })
            }
            className="bg-strawberry hover:bg-strawberry/90 text-white text-sm font-semibold px-5 py-2.5 rounded-full shadow-soft hover:shadow-softHover transition-all duration-200"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
