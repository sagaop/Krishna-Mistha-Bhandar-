# Krishna Mistha Bhandar — Complete Setup Guide (Phone-Friendly, No Coding Experience Needed)

This guide assumes you're doing everything from your phone's browser (Chrome or Safari) and have never coded before. Follow every step in order — don't skip ahead. It should take about 30–45 minutes.

You'll use 3 free websites: **Supabase** (your database), **GitHub** (stores your code), **Vercel** (makes your website live).

---

## PART 1 — Create your database (Supabase)

1. Open your phone browser and go to **supabase.com**
2. Tap **Start your project** → sign up with your email or GitHub (free, no card needed)
3. Tap **New Project**
   - Name: `krishna-mistha-bhandar`
   - Database password: create one and **save it in your Notes app** — you won't need it again for this guide, but keep it safe
   - Region: pick the one closest to Nepal (e.g. Singapore)
   - Tap **Create new project** and wait ~2 minutes
4. Once it's ready, look at the left sidebar (tap the ☰ menu if you don't see it) and tap **SQL Editor**
5. Tap **New query**
6. Open the file `supabase/schema.sql` from the project folder I gave you (open it with any text/notes app, or tap it in your Files app to preview, then select all and copy)
7. Paste the entire thing into the SQL Editor box on Supabase
8. Tap **Run** (usually a ▶ button, bottom right)
9. You should see "Success. No rows returned." — that means it worked
10. Confirm it: in the left sidebar tap **Table Editor** — you should see `products`, `bundles`, and `orders` tables (empty, which is correct — you'll add your own items later)

### Get your two keys (you'll need these soon)
1. Tap the **gear icon ⚙️ (Project Settings)** in the left sidebar
2. Tap **API**
3. You'll see two things — copy each into your Notes app:
   - **Project URL** (looks like `https://xxxxx.supabase.co`)
   - **anon public** key (a long string of letters/numbers)

---

## PART 2 — Put your code on GitHub

1. Go to **github.com** in your browser → **Sign up** (free)
2. Once logged in, tap the **+** icon (top right) → **New repository**
3. Repository name: `krishna-mistha-bhandar`
4. Keep it **Public**, don't check any other boxes
5. Tap **Create repository**

Now you need to add all the project files. You have two options:

### Option A (easier if it works on your phone): Upload the whole folder at once
1. First, unzip the project file I gave you:
   - **Android**: open the Files app, tap the `.zip` file → **Extract**
   - **iPhone**: open the Files app, tap the `.zip` file → it unzips automatically into a folder
2. On your new GitHub repository page, tap **Add file → Upload files**
3. Tap the upload box → choose **Browse** or **Files** → select the unzipped `sweet-celebrations` folder (some phones let you select the whole folder; others only let you multi-select files)
4. If your phone lets you select the whole folder — great, upload it and skip to "Commit" below
5. If it only lets you pick individual files, use **Option B** instead (it's slower but always works)

### Option B (always works, just more taps): Create each file by hand
For every file in the project, do this:
1. On your GitHub repo page, tap **Add file → Create new file**
2. In the "Name your file" box, type the **full path** exactly, for example: `app/page.jsx` — GitHub automatically creates the `app` folder for you
3. Open that same file on your phone (from the unzipped folder), select all the text, copy it
4. Paste it into GitHub's big text box
5. Scroll down, tap **Commit changes**
6. Repeat for every file. Here's the full list of files/paths to create, in this order:

```
package.json
postcss.config.js
tailwind.config.js
.env.local.example
lib/supabaseClient.js
app/layout.jsx
app/globals.css
app/page.jsx
app/admin/page.jsx
components/CartContext.jsx
components/Header.jsx
components/Hero.jsx
components/ProductCard.jsx
components/CartModal.jsx
components/admin/ProductForm.jsx
components/admin/ManageCatalog.jsx
components/admin/OrdersTable.jsx
supabase/schema.sql
```

This is the only tedious part — after this, everything else is just tapping buttons.

---

## PART 3 — Make it a live website (Vercel)

1. Go to **vercel.com** in your browser
2. Tap **Sign Up** → choose **Continue with GitHub** (this links your accounts, no separate password needed)
3. Once logged in, tap **Add New → Project**
4. Find your `krishna-mistha-bhandar` repository in the list and tap **Import**
5. Before deploying, tap to expand **Environment Variables** and add these two (paste the values you saved from Supabase in Part 1):

   | Name | Value |
   |---|---|
   | `NEXT_PUBLIC_SUPABASE_URL` | your Project URL |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | your anon public key |

6. Tap **Deploy**
7. Wait 1–2 minutes. When it's done, you'll see "Congratulations" with a link like `krishna-mistha-bhandar.vercel.app` — **that's your live website**

Open that link:
- The homepage is your storefront (share this link with customers)
- Add `/admin` to the end of the link (e.g. `krishna-mistha-bhandar.vercel.app/admin`) to reach your admin dashboard — this is where you add products, photos, prices, and tags, and manage orders

---

## PART 4 — Using your store day to day

**To add a product or bundle:**
1. Go to `yoursite.vercel.app/admin`
2. Fill in the "Create Product / Bundle" form — title, description, category, price (in Rs.), and an image URL
3. Optionally type a tag like `Best Seller` or `Low Price Today` and tap **Add** — you can add as many tags as you want, or none at all
4. Tap **Save to Database** — it appears on your storefront instantly

**To add/remove a tag on something you already saved**, or to delete an item:
- Scroll to **"Manage Products & Tags"** on the admin page — every product/bundle is listed there with its current tags. Type a new tag and tap **Add Tag**, or tap the **×** on a tag to remove it, or tap **Delete** to remove the item entirely.

**To see and update orders:**
- The **Incoming Orders** table on `/admin` shows every order as customers place them. Tap the status button to flip it between **Pending** and **Delivered**.

**About images:** For now, images are added by pasting a link (URL) to a photo hosted online. A free easy option: upload your photo to **postimages.org** (no account needed), then copy the "Direct link" it gives you and paste that into the Image URL field.

---

## A note on security

Right now, anyone who has your `/admin` link could add or delete products, since there's no login yet. This is fine to get started, but before sharing your storefront widely, it's worth adding a simple password login to `/admin`. Just ask and I can add that next.
